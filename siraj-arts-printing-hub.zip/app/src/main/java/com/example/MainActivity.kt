package com.example

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.AppDatabase
import com.example.data.model.ShopDetails
import com.example.data.repository.OrderRepository
import com.example.ui.components.OrderFormCard
import com.example.ui.components.OrderHistoryView
import com.example.ui.components.ServiceGridSelector
import com.example.ui.components.ShopAboutCard
import com.example.ui.components.ShopHeroBanner
import com.example.ui.components.ShopTopBar
import com.example.ui.theme.BackgroundLight
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ShopBlack
import com.example.ui.theme.ShopYellow
import com.example.ui.viewmodel.OrderViewModel
import com.example.ui.viewmodel.OrderViewModelFactory
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getInstance(applicationContext)
        val repository = OrderRepository(database.orderDao())
        val factory = OrderViewModelFactory(repository)

        setContent {
            MyApplicationTheme {
                val viewModel: OrderViewModel = viewModel(factory = factory)
                SirajArtsApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun SirajArtsApp(
    viewModel: OrderViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val savedOrders by viewModel.savedOrders.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) }

    // Launch WhatsApp helper
    fun openWhatsApp(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse(url)
                setPackage("com.whatsapp")
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // If WhatsApp package is not found or fails, open in browser or chooser
            try {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                context.startActivity(webIntent)
            } catch (fallbackEx: Exception) {
                Toast.makeText(context, "Could not open WhatsApp: ${fallbackEx.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // Direct Call helper
    fun openDialer() {
        try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse(ShopDetails.getCallUri())
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Could not open dialer", Toast.LENGTH_SHORT).show()
        }
    }

    // Google Maps helper
    fun openMaps() {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse(ShopDetails.getMapsUri())
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            val webMaps = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(ShopDetails.FULL_ADDRESS))
            )
            context.startActivity(webMaps)
        }
    }

    // Show info message in snackbar if set
    LaunchedEffect(uiState.infoMessage) {
        uiState.infoMessage?.let {
            snackbarHostState.showSnackbar(it)
        }
    }

    LaunchedEffect(uiState.validationError) {
        uiState.validationError?.let {
            snackbarHostState.showSnackbar(it)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            ShopTopBar(
                onDirectWhatsApp = { openWhatsApp(ShopDetails.getDirectShopWhatsAppUri()) },
                onDirectCall = { openDialer() }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = ShopBlack,
                contentColor = Color.White
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Print,
                            contentDescription = "New Order"
                        )
                    },
                    label = {
                        Text(
                            text = "New Order",
                            fontSize = 11.sp,
                            fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = ShopYellow,
                        indicatorColor = ShopYellow,
                        unselectedIconColor = Color(0xFF94A3B8),
                        unselectedTextColor = Color(0xFF94A3B8)
                    ),
                    modifier = Modifier.testTag("nav_new_order")
                )

                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (savedOrders.isNotEmpty()) {
                                    Badge(
                                        containerColor = ShopYellow,
                                        contentColor = Color.Black
                                    ) {
                                        Text("${savedOrders.size}")
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = "Recent Orders"
                            )
                        }
                    },
                    label = {
                        Text(
                            text = "My Orders",
                            fontSize = 11.sp,
                            fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = ShopYellow,
                        indicatorColor = ShopYellow,
                        unselectedIconColor = Color(0xFF94A3B8),
                        unselectedTextColor = Color(0xFF94A3B8)
                    ),
                    modifier = Modifier.testTag("nav_recent_orders")
                )

                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "About Shop"
                        )
                    },
                    label = {
                        Text(
                            text = "About Shop",
                            fontSize = 11.sp,
                            fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = ShopYellow,
                        indicatorColor = ShopYellow,
                        unselectedIconColor = Color(0xFF94A3B8),
                        unselectedTextColor = Color(0xFF94A3B8)
                    ),
                    modifier = Modifier.testTag("nav_about_shop")
                )
            }
        },
        containerColor = BackgroundLight
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> {
                    // Main Order Screen
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("screen_order_form")
                    ) {
                        // Hero Header with Sawai Madhopur Printing Hub
                        item {
                            ShopHeroBanner(
                                onOpenMap = { openMaps() },
                                onDirectCall = { openDialer() },
                                onDirectWhatsApp = { openWhatsApp(ShopDetails.getDirectShopWhatsAppUri()) }
                            )
                        }

                        // 2-Column Services Selector Grid
                        item {
                            ServiceGridSelector(
                                selectedService = uiState.selectedService,
                                onSelectService = { service -> viewModel.selectService(service) }
                            )
                        }

                        // Order Form Card
                        item {
                            OrderFormCard(
                                uiState = uiState,
                                onNameChange = { viewModel.onNameChange(it) },
                                onMobileChange = { viewModel.onMobileChange(it) },
                                onWidthChange = { viewModel.onWidthChange(it) },
                                onHeightChange = { viewModel.onHeightChange(it) },
                                onSizePreset = { w, h -> viewModel.setSizePreset(w, h) },
                                onQtyChange = { viewModel.onQtyChange(it) },
                                onIncrementQty = { viewModel.incrementQty() },
                                onDecrementQty = { viewModel.decrementQty() },
                                onMatterChange = { viewModel.onMatterChange(it) },
                                onSubmitOrder = {
                                    viewModel.submitOrder { waUrl ->
                                        openWhatsApp(waUrl)
                                    }
                                }
                            )
                        }

                        // Bottom Spacing
                        item {
                            Spacer(modifier = Modifier.height(24.dp))
                        }
                    }
                }

                1 -> {
                    // Recent Saved Orders
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("screen_recent_orders")
                    ) {
                        item {
                            OrderHistoryView(
                                orders = savedOrders,
                                onReorder = { order ->
                                    viewModel.loadOrderForReorder(order) {
                                        selectedTab = 0
                                    }
                                },
                                onResendWhatsApp = { url -> openWhatsApp(url) },
                                onDeleteOrder = { id -> viewModel.deleteOrder(id) },
                                onClearAll = { viewModel.clearAllHistory() },
                                onGoToForm = { selectedTab = 0 }
                            )
                        }

                        item {
                            Spacer(modifier = Modifier.height(24.dp))
                        }
                    }
                }

                2 -> {
                    // About Shop & Contact
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("screen_about_shop")
                    ) {
                        item {
                            ShopHeroBanner(
                                onOpenMap = { openMaps() },
                                onDirectCall = { openDialer() },
                                onDirectWhatsApp = { openWhatsApp(ShopDetails.getDirectShopWhatsAppUri()) }
                            )
                        }

                        item {
                            ShopAboutCard(
                                onDirectCall = { openDialer() },
                                onDirectWhatsApp = { openWhatsApp(ShopDetails.getDirectShopWhatsAppUri()) },
                                onOpenMap = { openMaps() }
                            )
                        }

                        item {
                            Spacer(modifier = Modifier.height(24.dp))
                        }
                    }
                }
            }
        }
    }
}
