package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SquareFoot
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PrintService
import com.example.data.model.ShopDetails
import com.example.ui.theme.BorderLight
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ShopBlack
import com.example.ui.theme.ShopWhatsApp
import com.example.ui.theme.ShopWhatsAppDark
import com.example.ui.theme.ShopYellow
import com.example.ui.theme.ShopYellowLight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.viewmodel.OrderFormUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OrderFormCard(
    uiState: OrderFormUiState,
    onNameChange: (String) -> Unit,
    onMobileChange: (String) -> Unit,
    onWidthChange: (String) -> Unit,
    onHeightChange: (String) -> Unit,
    onSizePreset: (String, String) -> Unit,
    onQtyChange: (String) -> Unit,
    onIncrementQty: () -> Unit,
    onDecrementQty: () -> Unit,
    onMatterChange: (String) -> Unit,
    onSubmitOrder: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showPreview by remember { mutableStateOf(false) }

    val wDouble = uiState.width.toDoubleOrNull()
    val hDouble = uiState.height.toDoubleOrNull()
    val totalSqFt = if (wDouble != null && hDouble != null) {
        val qtyInt = uiState.qty.toIntOrNull() ?: 1
        val single = wDouble * hDouble
        val total = single * qtyInt
        Pair(single, total)
    } else null

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("order_form_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Card Title & Service Tag
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Order Form - Sawai Madhopur",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimaryLight
                    )
                    Text(
                        text = "Direct WhatsApp order to Siraj Arts",
                        fontSize = 11.sp,
                        color = TextSecondaryLight
                    )
                }

                Surface(
                    color = ShopYellowLight,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ShopYellow)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = uiState.selectedService.iconEmoji, fontSize = 14.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = uiState.selectedService.name,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF78350F)
                        )
                    }
                }
            }

            // Validation Error Alert (Naam aur 10 digit Mobile bharo)
            AnimatedVisibility(
                visible = uiState.validationError != null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                uiState.validationError?.let { error ->
                    Surface(
                        color = ErrorRed.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ErrorRed),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp)
                            .testTag("validation_error_banner")
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = ErrorRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = error,
                                color = ErrorRed,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Customer Name Field
            Text(
                text = "Aapka Naam (Customer Name) *",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryLight
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = uiState.name,
                onValueChange = onNameChange,
                placeholder = { Text("e.g. Ramesh Sharma / Sawai Madhopur", fontSize = 13.sp, color = TextMuted) },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = TextMuted)
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_customer_name"),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ShopYellow,
                    unfocusedBorderColor = BorderLight,
                    focusedContainerColor = Color(0xFFFFFBEB),
                    unfocusedContainerColor = Color(0xFFF8FAFC)
                )
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 10-Digit Mobile Number Field
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "10-Digit Mobile Number *",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryLight
                )
                Text(
                    text = "${uiState.mobile.length}/10 digits",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (uiState.mobile.length == 10) Color(0xFF059669) else TextMuted
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = uiState.mobile,
                onValueChange = onMobileChange,
                placeholder = { Text("9001470239", fontSize = 13.sp, color = TextMuted) },
                leadingIcon = {
                    Row(
                        modifier = Modifier.padding(start = 12.dp, end = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "+91",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryLight
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .width(1.dp)
                                .height(16.dp)
                                .background(BorderLight)
                        )
                    }
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_customer_mobile"),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ShopYellow,
                    unfocusedBorderColor = BorderLight,
                    focusedContainerColor = Color(0xFFFFFBEB),
                    unfocusedContainerColor = Color(0xFFF8FAFC)
                )
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Dimensions: Width & Height
            val unit = uiState.selectedService.unit
            Text(
                text = "Size / Dimensions (in $unit)",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryLight
            )
            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = uiState.width,
                    onValueChange = onWidthChange,
                    label = { Text("Width ($unit)", fontSize = 11.sp) },
                    placeholder = { Text("e.g. 6", fontSize = 12.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("input_width"),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ShopYellow,
                        unfocusedBorderColor = BorderLight,
                        unfocusedContainerColor = Color(0xFFF8FAFC)
                    )
                )

                OutlinedTextField(
                    value = uiState.height,
                    onValueChange = onHeightChange,
                    label = { Text("Height ($unit)", fontSize = 11.sp) },
                    placeholder = { Text("e.g. 3", fontSize = 12.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("input_height"),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ShopYellow,
                        unfocusedBorderColor = BorderLight,
                        unfocusedContainerColor = Color(0xFFF8FAFC)
                    )
                )
            }

            // Quick size suggestions for standard flex/banners
            if (unit == "ft") {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Quick Sizes:",
                        fontSize = 11.sp,
                        color = TextMuted,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf(
                            Pair("3", "2"),
                            Pair("6", "3"),
                            Pair("8", "4"),
                            Pair("10", "4"),
                            Pair("12", "6"),
                            Pair("20", "10")
                        ).forEach { (w, h) ->
                            val isCurrent = uiState.width == w && uiState.height == h
                            Surface(
                                color = if (isCurrent) ShopYellow else Color(0xFFF1F5F9),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.clickable { onSizePreset(w, h) }
                            ) {
                                Text(
                                    text = "${w}x${h} ft",
                                    fontSize = 10.sp,
                                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isCurrent) Color.Black else TextPrimaryLight,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Total Sq Ft Calculation Banner
            if (totalSqFt != null && unit == "ft") {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = Color(0xFFF0FDF4),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBF7D0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.SquareFoot,
                            contentDescription = null,
                            tint = Color(0xFF16A34A),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Size: ${String.format("%.1f", totalSqFt.first)} sq. ft" +
                                    (if (uiState.qty != "1") " (Total: ${String.format("%.1f", totalSqFt.second)} sq. ft for ${uiState.qty} pcs)" else ""),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF166534)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quantity with +/- Stepper
            Text(
                text = "Quantity (Pcs)",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryLight
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFFF8FAFC))
                    .border(1.dp, BorderLight, RoundedCornerShape(14.dp))
                    .padding(horizontal = 6.dp, vertical = 4.dp)
            ) {
                IconButton(
                    onClick = onDecrementQty,
                    modifier = Modifier.size(36.dp).testTag("btn_qty_minus")
                ) {
                    Icon(imageVector = Icons.Default.Remove, contentDescription = "Decrease", tint = TextPrimaryLight)
                }

                OutlinedTextField(
                    value = uiState.qty,
                    onValueChange = onQtyChange,
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .width(70.dp)
                        .testTag("input_qty"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    )
                )

                IconButton(
                    onClick = onIncrementQty,
                    modifier = Modifier.size(36.dp).testTag("btn_qty_plus")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Increase", tint = TextPrimaryLight)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Matter / Text to Print
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Matter / Printing Text (Design Content)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryLight
                )
                Text(
                    text = "Optional",
                    fontSize = 10.sp,
                    color = TextMuted
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = uiState.matter,
                onValueChange = onMatterChange,
                placeholder = {
                    Text(
                        "Describe what text, shop name, phone numbers, photo or design matter you want printed...",
                        fontSize = 12.sp,
                        color = TextMuted,
                        lineHeight = 16.sp
                    )
                },
                minLines = 3,
                maxLines = 6,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_matter"),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ShopYellow,
                    unfocusedBorderColor = BorderLight,
                    focusedContainerColor = Color(0xFFFFFBEB),
                    unfocusedContainerColor = Color(0xFFF8FAFC)
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Toggle preview of WhatsApp message
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showPreview = !showPreview }
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = Color(0xFF2563EB),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (showPreview) "Hide WhatsApp message preview" else "Preview WhatsApp message",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF2563EB)
                    )
                }
                Text(
                    text = if (showPreview) "▲" else "▼",
                    fontSize = 10.sp,
                    color = Color(0xFF2563EB)
                )
            }

            AnimatedVisibility(visible = showPreview) {
                val previewMsg = ShopDetails.buildOrderMessage(
                    service = uiState.selectedService.name,
                    customerName = uiState.name.ifBlank { "[Customer Name]" },
                    customerMobile = uiState.mobile.ifBlank { "[Mobile]" },
                    width = uiState.width,
                    height = uiState.height,
                    qty = uiState.qty,
                    matter = uiState.matter,
                    unit = uiState.selectedService.unit
                )

                Surface(
                    color = Color(0xFFDCF8C6), // WhatsApp chat green bubble
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "WhatsApp Message Preview:",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E3A1E)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = previewMsg,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = Color(0xFF1F2937),
                            lineHeight = 15.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Big Send Order on WhatsApp Button
            Button(
                onClick = onSubmitOrder,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("btn_send_whatsapp"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ShopWhatsApp,
                    contentColor = Color.White
                ),
                elevation = ButtonDefaults.buttonElevation(
                    defaultElevation = 4.dp,
                    pressedElevation = 2.dp
                )
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "🔥",
                        fontSize = 18.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Send Order on WhatsApp",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.3.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "⚡ Your order goes directly to Siraj Arts owner (${ShopDetails.DISPLAY_PHONE}) for instant pricing & proof approval.",
                fontSize = 10.sp,
                color = TextMuted,
                lineHeight = 14.sp
            )
        }
    }
}
