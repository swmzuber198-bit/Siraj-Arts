package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.OrderEntity
import com.example.data.model.PrintService
import com.example.data.model.ServiceCatalog
import com.example.data.model.ShopDetails
import com.example.data.repository.OrderRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class OrderFormUiState(
    val selectedService: PrintService = ServiceCatalog.services.first(),
    val name: String = "",
    val mobile: String = "",
    val width: String = "",
    val height: String = "",
    val qty: String = "1",
    val matter: String = "",
    val validationError: String? = null,
    val infoMessage: String? = null
)

class OrderViewModel(
    private val repository: OrderRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(OrderFormUiState())
    val uiState: StateFlow<OrderFormUiState> = _uiState.asStateFlow()

    val savedOrders: StateFlow<List<OrderEntity>> = repository.allOrders
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun selectService(service: PrintService) {
        _uiState.value = _uiState.value.copy(
            selectedService = service,
            width = if (_uiState.value.width.isBlank()) service.defaultWidth else _uiState.value.width,
            height = if (_uiState.value.height.isBlank()) service.defaultHeight else _uiState.value.height,
            validationError = null
        )
    }

    fun onNameChange(name: String) {
        _uiState.value = _uiState.value.copy(
            name = name,
            validationError = null
        )
    }

    fun onMobileChange(rawMobile: String) {
        // Keep only digits, up to 10
        val filtered = rawMobile.filter { it.isDigit() }.take(10)
        _uiState.value = _uiState.value.copy(
            mobile = filtered,
            validationError = null
        )
    }

    fun onWidthChange(width: String) {
        val filtered = width.filter { it.isDigit() || it == '.' }.take(6)
        _uiState.value = _uiState.value.copy(width = filtered)
    }

    fun onHeightChange(height: String) {
        val filtered = height.filter { it.isDigit() || it == '.' }.take(6)
        _uiState.value = _uiState.value.copy(height = filtered)
    }

    fun setSizePreset(w: String, h: String) {
        _uiState.value = _uiState.value.copy(width = w, height = h)
    }

    fun onQtyChange(qty: String) {
        val filtered = qty.filter { it.isDigit() }.take(4)
        _uiState.value = _uiState.value.copy(qty = if (filtered.isEmpty()) "1" else filtered)
    }

    fun incrementQty() {
        val current = _uiState.value.qty.toIntOrNull() ?: 1
        _uiState.value = _uiState.value.copy(qty = (current + 1).toString())
    }

    fun decrementQty() {
        val current = _uiState.value.qty.toIntOrNull() ?: 1
        if (current > 1) {
            _uiState.value = _uiState.value.copy(qty = (current - 1).toString())
        }
    }

    fun onMatterChange(matter: String) {
        _uiState.value = _uiState.value.copy(matter = matter)
    }

    fun clearValidationError() {
        _uiState.value = _uiState.value.copy(validationError = null, infoMessage = null)
    }

    /**
     * Exact validation from user's React prompt:
     * if (!name || mobile.length !== 10) { alert("Naam aur 10 digit Mobile bharo"); return; }
     */
    fun submitOrder(
        onLaunchWhatsApp: (url: String) -> Unit
    ) {
        val current = _uiState.value
        val trimmedName = current.name.trim()
        val trimmedMobile = current.mobile.trim()

        if (trimmedName.isEmpty() || trimmedMobile.length != 10) {
            _uiState.value = current.copy(
                validationError = "Naam aur 10 digit Mobile bharo"
            )
            return
        }

        val message = ShopDetails.buildOrderMessage(
            service = current.selectedService.name,
            customerName = trimmedName,
            customerMobile = trimmedMobile,
            width = current.width,
            height = current.height,
            qty = current.qty,
            matter = current.matter,
            unit = current.selectedService.unit
        )

        // Save into local Room database for customer's reference
        viewModelScope.launch {
            repository.insertOrder(
                OrderEntity(
                    service = current.selectedService.name,
                    customerName = trimmedName,
                    customerMobile = trimmedMobile,
                    width = current.width,
                    height = current.height,
                    unit = current.selectedService.unit,
                    quantity = current.qty,
                    matter = current.matter,
                    formattedMessage = message
                )
            )
        }

        _uiState.value = current.copy(
            validationError = null,
            infoMessage = "Order saved! Opening WhatsApp..."
        )

        val whatsappUri = ShopDetails.getWhatsAppUri(message)
        onLaunchWhatsApp(whatsappUri)
    }

    fun loadOrderForReorder(order: OrderEntity, onTabSwitch: () -> Unit) {
        val matchingService = ServiceCatalog.services.find { it.name == order.service }
            ?: ServiceCatalog.services.first()

        _uiState.value = _uiState.value.copy(
            selectedService = matchingService,
            name = order.customerName,
            mobile = order.customerMobile,
            width = order.width,
            height = order.height,
            qty = order.quantity,
            matter = order.matter,
            validationError = null,
            infoMessage = "Loaded details from previous order"
        )
        onTabSwitch()
    }

    fun deleteOrder(id: Long) {
        viewModelScope.launch {
            repository.deleteOrder(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAll()
        }
    }
}

class OrderViewModelFactory(
    private val repository: OrderRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(OrderViewModel::class.java)) {
            return OrderViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
