package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ShopBlack = Color(0xFF0A0C10)
val ShopDarkHeader = Color(0xFF11141C)
val ShopDarkCard = Color(0xFF1A1E29)

val ShopYellow = Color(0xFFFACC15) // Tailwind yellow-400
val ShopAmber = Color(0xFFF59E0B)  // Tailwind amber-500
val ShopYellowDark = Color(0xFFD97706)
val ShopYellowLight = Color(0xFFFEF08A)

val ShopWhatsApp = Color(0xFF25D366)
val ShopWhatsAppDark = Color(0xFF128C7E)
val ShopCallBlue = Color(0xFF2563EB)
val ShopMapRed = Color(0xFFDC2626)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceSubtle = Color(0xFFF1F5F9)

val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)
val TextMuted = Color(0xFF94A3B8)

val BorderLight = Color(0xFFE2E8F0)
val BorderFocused = Color(0xFFF59E0B)

val ErrorRed = Color(0xFFEF4444)
val SuccessGreen = Color(0xFF10B981)
