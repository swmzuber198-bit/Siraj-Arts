package com.example.data.model

import androidx.compose.ui.graphics.Color

data class PrintService(
    val id: String,
    val name: String,
    val hindiName: String,
    val iconEmoji: String,
    val description: String,
    val startColor: Color,
    val endColor: Color,
    val defaultWidth: String = "",
    val defaultHeight: String = "",
    val unit: String = "ft",
    val highlightBadge: String = ""
)

object ServiceCatalog {
    val services = listOf(
        PrintService(
            id = "flex_banner",
            name = "Flex Banner",
            hindiName = "फ्लेक्स बैनर",
            iconEmoji = "🎨",
            description = "High quality Star/Frontlit flex for shops, political ads, events & hoarding boards",
            startColor = Color(0xFFFB923C), // orange-400
            endColor = Color(0xFFEF4444),   // red-500
            defaultWidth = "6",
            defaultHeight = "3",
            highlightBadge = "Most Popular"
        ),
        PrintService(
            id = "led_glow_board",
            name = "LED Glow Board",
            hindiName = "एलईडी ग्लो बोर्ड",
            iconEmoji = "💡",
            description = "Bright night-illuminated LED back-lit signboards with durable metal casing",
            startColor = Color(0xFFFACC15), // yellow-400
            endColor = Color(0xFFF97316),   // orange-500
            defaultWidth = "8",
            defaultHeight = "3",
            highlightBadge = "Night Glow"
        ),
        PrintService(
            id = "hoarding",
            name = "Hoarding",
            hindiName = "होर्डिंग / यूनिपोल",
            iconEmoji = "🏗️",
            description = "Large scale highway, road & rooftop billboards with heavy duty steel framing",
            startColor = Color(0xFF60A5FA), // blue-400
            endColor = Color(0xFF6366F1),   // indigo-500
            defaultWidth = "20",
            defaultHeight = "10",
            highlightBadge = "Large Size"
        ),
        PrintService(
            id = "vinyl_print",
            name = "Vinyl Print",
            hindiName = "विनाइल प्रिंट / स्टीकर",
            iconEmoji = "🖨️",
            description = "Waterproof matte/glossy adhesive sticker vinyl for glass doors, walls & cars",
            startColor = Color(0xFFC084FC), // purple-400
            endColor = Color(0xFFEC4899),   // pink-500
            defaultWidth = "4",
            defaultHeight = "2",
            highlightBadge = "Waterproof"
        ),
        PrintService(
            id = "bike_number_plate",
            name = "Bike Number Plate",
            hindiName = "बाइक नंबर प्लेट",
            iconEmoji = "🏍️",
            description = "Embossed metal, IND style & stylish designer fonts for motorcycles & scooters",
            startColor = Color(0xFF4ADE80), // green-400
            endColor = Color(0xFF059669),   // emerald-600
            defaultWidth = "8",
            defaultHeight = "4",
            unit = "inch",
            highlightBadge = "Fast Delivery"
        ),
        PrintService(
            id = "name_plate",
            name = "Name Plate",
            hindiName = "नेम प्लेट (होम / ऑफिस)",
            iconEmoji = "🏠",
            description = "Laser cut acrylic, stainless steel & golden embossed name plates for home & office",
            startColor = Color(0xFF374151), // gray-700
            endColor = Color(0xFF111827),   // black
            defaultWidth = "12",
            defaultHeight = "6",
            unit = "inch",
            highlightBadge = "Premium"
        )
    )
}
