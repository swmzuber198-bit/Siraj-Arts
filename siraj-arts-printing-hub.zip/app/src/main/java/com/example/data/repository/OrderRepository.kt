package com.example.data.repository

import com.example.data.local.OrderDao
import com.example.data.local.OrderEntity
import kotlinx.coroutines.flow.Flow

class OrderRepository(private val orderDao: OrderDao) {
    val allOrders: Flow<List<OrderEntity>> = orderDao.getAllOrders()

    suspend fun insertOrder(order: OrderEntity): Long {
        return orderDao.insertOrder(order)
    }

    suspend fun deleteOrder(id: Long) {
        orderDao.deleteOrderById(id)
    }

    suspend fun clearAll() {
        orderDao.deleteAllOrders()
    }
}
