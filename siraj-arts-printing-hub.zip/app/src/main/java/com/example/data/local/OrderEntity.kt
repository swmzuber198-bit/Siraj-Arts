package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val service: String,
    val customerName: String,
    val customerMobile: String,
    val width: String,
    val height: String,
    val unit: String = "ft",
    val quantity: String,
    val matter: String,
    val formattedMessage: String,
    val timestamp: Long = System.currentTimeMillis()
)
