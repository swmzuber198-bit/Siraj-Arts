package com.example.data.model

import java.net.URLEncoder

object ShopDetails {
    const val OWNER_PHONE = "919001470239"
    const val DISPLAY_PHONE = "9001470239"
    const val FULL_ADDRESS = "Siraj Arts, Near Bus Stand, Sawai Madhopur, Rajasthan - 322001"
    const val SHOP_NAME = "Siraj Arts"
    const val HUB_NAME = "Sawai Madhopur Printing Hub"
    const val CITY = "Sawai Madhopur"
    const val PINCODE = "322001"

    /**
     * Builds the formatted WhatsApp order message as specified in the business logic:
     * *🔥 NEW ORDER - SAWAI MADHOPUR*
     *
     * *Service:* {service}
     * *Customer:* {name}
     * *Mobile:* {mobile}
     * *Size:* {width}x{height} ft
     * *Qty:* {qty}
     * *Matter:* {matter}
     *
     * *Shop Address:* {FULL_ADDRESS}
     */
    fun buildOrderMessage(
        service: String,
        customerName: String,
        customerMobile: String,
        width: String,
        height: String,
        qty: String,
        matter: String,
        unit: String = "ft"
    ): String {
        val sizeFormatted = if (width.isNotBlank() && height.isNotBlank()) {
            "${width.trim()}x${height.trim()} $unit"
        } else if (width.isNotBlank() || height.isNotBlank()) {
            "${width.ifBlank { "-" }}x${height.ifBlank { "-" }} $unit"
        } else {
            "Standard Size"
        }

        val qtyFormatted = if (qty.isNotBlank()) qty.trim() else "1"
        val matterFormatted = if (matter.isNotBlank()) matter.trim() else "To be discussed on WhatsApp / Call"

        return "*🔥 NEW ORDER - SAWAI MADHOPUR*\n\n" +
                "*Service:* $service\n" +
                "*Customer:* ${customerName.trim()}\n" +
                "*Mobile:* ${customerMobile.trim()}\n" +
                "*Size:* $sizeFormatted\n" +
                "*Qty:* $qtyFormatted\n" +
                "*Matter:* $matterFormatted\n\n" +
                "*Shop Address:* $FULL_ADDRESS"
    }

    /**
     * Encodes the WhatsApp message for direct URI intent: https://wa.me/919001470239?text=...
     */
    fun getWhatsAppUri(message: String): String {
        val encodedMessage = URLEncoder.encode(message, "UTF-8")
        return "https://wa.me/$OWNER_PHONE?text=$encodedMessage"
    }

    fun getDirectShopWhatsAppUri(): String {
        val greeting = URLEncoder.encode("Hello Siraj Arts, I want to inquire about printing services in Sawai Madhopur.", "UTF-8")
        return "https://wa.me/$OWNER_PHONE?text=$greeting"
    }

    fun getCallUri(): String {
        return "tel:+$OWNER_PHONE"
    }

    fun getMapsUri(): String {
        val encodedLocation = URLEncoder.encode("Siraj Arts Near Bus Stand Sawai Madhopur Rajasthan 322001", "UTF-8")
        return "geo:0,0?q=$encodedLocation"
    }
}
