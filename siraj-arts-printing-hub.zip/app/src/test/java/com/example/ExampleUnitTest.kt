package com.example

import com.example.data.model.ShopDetails
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testWhatsAppMessageFormatting() {
    val msg = ShopDetails.buildOrderMessage(
      service = "Flex Banner",
      customerName = "Ramesh",
      customerMobile = "9001470239",
      width = "6",
      height = "3",
      qty = "1",
      matter = "Sawai Madhopur Store Opening"
    )

    assertTrue(msg.contains("*Service:* Flex Banner"))
    assertTrue(msg.contains("*Customer:* Ramesh"))
    assertTrue(msg.contains("*Mobile:* 9001470239"))
    assertTrue(msg.contains("*Size:* 6x3 ft"))
    assertTrue(msg.contains(ShopDetails.FULL_ADDRESS))
  }
}

